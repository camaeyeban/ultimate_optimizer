CreateOutput <- function(goal, tableau, iteration_number){
  # variable initializations
  total_row_count = nrow(tableau);
  total_column_count = ncol(tableau);
  column_names = colnames(tableau);
  basic_solution = matrix(data = NA, nrow = total_column_count-2, ncol = 2,
                          dimnames = list(c(1:(total_column_count-2)), c("Variable", "Value")),
                          byrow = FALSE);
  
  # if the goal is to maximize
  if(goal == 1){
    for(i in seq( 1:nrow(basic_solution) )){
      filled = entry_index = 0;
      for(j in seq(1:total_row_count)){
        if(tableau[j,i] != 0){
          filled = filled + 1;
          entry_index = j;
        }
      }
      basic_solution[i, 1] = column_names[i];
      
      # basic solution will either be zero or data from solution column
      if(filled != 1){
        basic_solution[i, 2] = 0;
      }
      else{
        basic_solution[i, 2] = tableau[entry_index, (total_column_count-1)];
      }
    }
  }
  
  # if the goal is to minimize
  else{
    for(i in seq( 1:nrow(basic_solution) )){
      # basic solution will come from the last row
      basic_solution[i, 1] = column_names[i];
      basic_solution[i, 2] = tableau[total_row_count, i];
    }
    basic_solution[i, 2] = tableau[total_row_count, total_column_count-1];
  }
  optimized_value = tableau[total_row_count, total_column_count-1];
  
  result_list = list(basic_solution = basic_solution, optimized_value = optimized_value);
  return(result_list);
}