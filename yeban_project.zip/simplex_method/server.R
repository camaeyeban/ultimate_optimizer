library(shiny)


source('initial_tableau_setup.r');
source('simplex_method.r');


shinyServer(function(input, output, session) {
  
  
  showResults <- function(iteration_results){
    output$number_of_iterations <- renderText({
      paste0("Number of iterations: ", length(iteration_results));
    })
    
    output$results <- renderUI({
      result_output_list <- lapply(1:(length(iteration_results)*4), function(i){
        output_name <- paste0("output_",i)
        uiOutput(output_name)
      })
      do.call(tagList, result_output_list)
    })
    
    for(i in 1:length(iteration_results)){
      local({
        my_i <- i
        iteration_name <- paste0("output_", my_i*4-3)
        
        output[[iteration_name]] <- renderUI({
          h1("Iteration ", my_i);
        })
        tableau_name <- paste0("output_",my_i*4-2)
        
        output[[tableau_name]] <- renderTable({
          iteration_results[[my_i]]$tableau
        })
        
        basic_solution_name <- paste0("output_",my_i*4-1)
        
        output[[basic_solution_name]] <- renderTable({
          iteration_results[[my_i]]$basic_solution
        })
        
        optimized_value_name <- paste0("output_",my_i*4)
        
        output[[optimized_value_name]] <- renderText({
          paste0("Optimized value: ", iteration_results[[my_i]]$optimized_value)
        })
      })
    }
  }
  
  
  # Track the number of constraint boxes and constraint input to render
  constraints <- reactiveValues(
    n = 0,
    constraint = array()
  );
  
  
  # Track optimization problem results
  results <- reactiveValues(
    iteration = list()
  );
  
  
  # update constraints data and count when add_constraint button is clicked
  observeEvent(input$add_constraint, {
    if(constraints$n > 0){
      constraints$constraint = array(data = "", dim = constraints$n + 1, dimnames = NULL);
      for(i in seq(1:constraints$n)){
        constraints$constraint[i] = input[[paste0("constraint", i)]]
      }
      constraints$constraint[constraints$n + 1] = "";
    }
    constraints$n <- constraints$n + 1;
  })
  
  
  # update constraints data and count when remove_constraint button is clicked
  observeEvent(input$remove_constraint, {
    if (constraints$n > 0){
      constraints$constraint = array(data = "", dim = constraints$n - 1, dimnames = NULL);
      for(i in seq(1:constraints$n - 1)){
        constraints$constraint[i] = input[[paste0("constraint", i)]];
      }
      constraints$n <- constraints$n - 1;
    }
  })
  
  
  # update constraints ui
  textboxes <- reactive({
    n <- constraints$n
    if (n > 0) {
      lapply(seq_len(n), function(i) {
        textInput(inputId = paste0("constraint", i),
          label = paste0("Constraint ", i),
          placeholder = "ex: 1 * x1 + 2 * x2 + 3 * x3 + 4 * x4 <= 10",
          value = constraints$constraint[i]
        )
      })
    }
    
  })
  
  
  # create a downloadable zip of csv files containing the tableau and
  # basic solution (with the optimized value) of each iteration
  output$download_results <- downloadHandler(
    filename = "iterations.zip",
    
    content = function(filename) {
      tmpdir <- tempdir()
      setwd(tempdir())
      print(tempdir())
      
      zip_data = array(data = NA, dim = length(results$iteration) * 2);
      for(i in seq(1:length(results$iteration))){
        # create csv file containing tableau of current iteration
        fn = paste0("iteration_",i,".csv");
        write.csv(results$iteration[[i]]$tableau, fn);
        zip_data[i] = fn;
        
        # create csv file containing basic solution (containing the optimized value) of current iteration
        fnb = paste0("iteration_",i,"_basic_solution.csv");
        write.csv(results$iteration[[i]]$basic_solution, fnb);
        zip_data[i+length(results$iteration)] = fnb;
      }
      
      # zip all created csv files
      zip(zipfile=filename, files=zip_data);
    },
    contentType = "application/zip"
    
  )
  
  
  # create a downloadable zip of sample csv input files
  output$download_samples <- downloadHandler(
    filename = "sample_files.zip",
    
    content = function(filename) {
      zip_data = array(data = NA, dim = 4);
      
      for(i in seq(1:length(zip_data))){
        # create csv file for each sample input
        fn = paste0("sample_files/example_",i,".csv");
        write.csv(fn);
        zip_data[i] = fn;
      }
      
      # zip all created csv files
      zip(zipfile=filename, files=zip_data);
    },
    contentType = "application/zip"
    
  )
  
  
  # process input file when the Solve button in first tab is clicked
  observeEvent(input$solve1, {
    inFile <- input$input_file
    if (is.null(inFile))
      return(NULL)
    
    tableau = read.csv(inFile$datapath, header=TRUE, sep=",", 
             quote='"', check.names=FALSE)
    results$iteration = SimplexMethod(input$goal_1, tableau, 10000);
    
    showResults(results$iteration);
  })
  
  
  # render updated constraint boxes
  output$constraint_textboxes <- renderUI({ textboxes() })
  
  
  # process input from text fields when the Solve button in second tab is clicked
  observeEvent(input$solve2, {
    for(i in seq(1:constraints$n)){
      constraints$constraint[i] = input[[paste0("constraint", i)]]
    }
    filtered_constraints = constraints$constraint[constraints$constraint != ""]
    
    result_list = SetupInitialTableau(input$goal, input$objective_function, filtered_constraints);
    results$iteration = SimplexMethod(input$goal, result_list$tableau, 10000);
    
    showResults(results$iteration);
  })
  
  
})