shinyUI(fluidPage(
  
  # title
  fluidRow(
    br(),
    h1("Ultimate Optimizer", align = "center")
  ),
  
  # project description
  fluidRow(
    column(2),
    column(8,
           helpText("The Ultimate Optimizer is a program that solves", 
                    "an optimization problem using Simplex Method.",
                    "It either maximizes or minimizes an objective",
                    "function considering the given constraints.",
                    align = "justify")
    ),
    column(2)
  ),
  
  hr(),
  
  # main body of app
  sidebarLayout(
    sidebarPanel(
      
      # tab panel for getting input from file
      tabsetPanel(
        tabPanel("Input from file",
          selectInput("goal_1",
                      label = h4("Goal"),
                      choices = list("Maximize" = 1, "Minimize" = 2),
                      selected = 1),
          fileInput("input_file", label = h4("File"),
                   accept = c(
                     'text/csv',
                     'text/comma-separated-values',
                     '.csv'
                   )
          ),
          hr(),
          fluidRow(
            column(12,actionButton("solve1", label = "Solve")),
            align = "center"
          ),
          hr(),
          fluidRow(
            column(12,
                   downloadButton('download_samples', 'Download File Input Samples'),
                   align = "center")
          )
        ),
        
        # tab pane for getting input from text fields
        tabPanel("Input from text fields",
            selectInput("goal",
                       label = h4("Goal"),
                       choices = list("Maximize" = 1, "Minimize" = 2),
                       selected = 1),
            
            textInput("objective_function", 
                     label = h4("Objective Function"),
                     placeholder = "ex: Z = 2 * x1 + 7 * x2 + 1 * x3 + 4 * x4"),
            
            h4("Constraints"),
            uiOutput("constraint_textboxes"),
            fluidRow(
              column(6,actionButton("add_constraint", "Add Constraint")),
              column(6,actionButton("remove_constraint", "Remove Constraint"))
            ),
            br(),
            
            hr(),
            fluidRow(
              column(12,actionButton("solve2", label = "Solve")),
              align = "center"
            )
        )
      )
    ),
    
    # output panel
    mainPanel(
      downloadButton('download_results', 'Download Results'),
      br(),
      br(),
      textOutput("number_of_iterations"),
      uiOutput("results")
    )
  ),
  hr(),
    
  # footer
  fluidRow(
    helpText("CMSC 150 EF-1L Project"),
    helpText("Erica Mae M. Yeban"), 
    helpText("2012 - 04540"), align = "center"
  ),
  br()
))
