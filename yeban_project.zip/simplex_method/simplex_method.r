this.dir <- dirname(parent.frame(2)$ofile)
setwd(this.dir)



# returns the index of pivot column
# returns -1 if no negative value was found at the last column
GetPivotColumn <- function(last_row, number_of_columns){
  val = 0;
  pivot_column_index = -1;
  
  for(i in seq(1:number_of_columns)){
    if(last_row[i] < 0 && val > last_row[i]){
      val = last_row[i];
      pivot_column_index = i;
    }
  }
  
  return(pivot_column_index);
}



# populates the test ratio column
# test ratio = solution column / pivot column
UpdateTestRatioColumn <- function(tableau, pivot_column_index){
  total_row_count = nrow(tableau);
  total_column_count = ncol(tableau);
  
  tableau[, total_column_count] = NA;
  for(i in seq(1:(total_row_count-1))){
    if(tableau[i, pivot_column_index] != 0 && i != total_row_count){
      tableau[i, total_column_count] = tableau[i, (total_column_count-1)] / tableau[i, pivot_column_index];
    }
  }
  
  return(tableau);
}


# returns pivot row index
GetPivotRow <- function(test_ratio_column){
  val = 0;
  pivot_row_index = -1;
  len = length(test_ratio_column) - 1;
  for(i in seq(1:len)){
    if(!is.na(test_ratio_column[i])){
      if(test_ratio_column[i] > 0 && (val > test_ratio_column[i] || pivot_row_index == -1) ){
        val = test_ratio_column[i];
        pivot_row_index = i;
      }
    }
  }
  
  return(pivot_row_index);
}


SimplexMethod <- function(goal, tableau, max_iteration){
  source('output_creation.r');
  # variable initializations
  iteration = 1;
  iteration_results = array(data = list(), dimnames = NULL);
  
  total_row_count = nrow(tableau);
  total_column_count = ncol(tableau);
  
  while(iteration <= max_iteration){
    pivot_column_index = GetPivotColumn(tableau[total_row_count, ], (total_column_count-2));
    
    # terminate if no negative value was found at the last column
    if(pivot_column_index == -1){
      break;
    }
    
    # updates values
    tableau = UpdateTestRatioColumn(tableau, pivot_column_index);
    pivot_row_index = GetPivotRow(tableau[, total_column_count]);
    pivot_element = tableau[pivot_row_index, pivot_column_index];
    
    result_list = CreateOutput(goal, tableau, iteration);
    optimized_value = result_list$optimized_value;
    basic_solution = result_list$basic_solution;
    iteration_result = list(tableau = tableau, basic_solution = basic_solution, optimized_value = optimized_value);
    iteration_results[[iteration]] <- iteration_result;
    
    #----------------------- NORMALIZATION -----------------------#
    tr = tableau[pivot_row_index, total_column_count];
    tableau[pivot_row_index, ] = tableau[pivot_row_index, ] / pivot_element;
    tableau[pivot_row_index, total_column_count] = tr;
    
    #------------------------ ELIMINATION ------------------------#
    for(i in seq(1:total_row_count)){
      if(i != pivot_row_index){
        temp = tableau[pivot_row_index, ] * tableau[i, pivot_column_index];
        tr = tableau[i, total_column_count];
        tableau[i, ] = tableau[i, ] - temp;
        tableau[i, total_column_count] = tr;
      }
    }
    
    # updates iteration number
    iteration = iteration+1;
    
  }
  # prompt if maximum number of iterations is reached
  if(iteration > max_iteration){
    print("Oooops! Maximum number of iterations reached. Process terminated.");
  }
  else{
    # update results to be returned
    tableau[, total_column_count] = NA;
    result_list = CreateOutput(goal, tableau, iteration);
    optimized_value = result_list$optimized_value;
    basic_solution = result_list$basic_solution;
    iteration_result = list(tableau = tableau, basic_solution = basic_solution, optimized_value = optimized_value);
    iteration_results[[iteration]] <- iteration_result;
    return(iteration_results);
  }
  return(NULL);
}