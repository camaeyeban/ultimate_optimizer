SetupInitialTableau <- function(goal, objective_function_string, constraints){
  # split the first equation in the system
  objective_function_split = unlist(strsplit(deparse(objective_function_string), "\\=|\n|\"|\\*|\\+| "));
  objective_function_split = objective_function_split[objective_function_split != ""];
  
  # optimization_variable: variable name of value to be maximized/minimized
  optimization_variable = objective_function_split[1];
  objective_function_split = objective_function_split[2:length(objective_function_split)];
  
  ##################### VARIABLE INITIALIZATION #####################
  variable_count = length(objective_function_split)/2;
  constraint_count = length(constraints);
  column_count = variable_count+constraint_count+3;
  row_count = constraint_count+1;
  
  variables = array(dim = variable_count, dimnames = NULL);
  solutions = array(data = 0, dim = row_count, dimnames = NULL);
  objective_function = array(data = 0, dim = variable_count, dimnames = NULL);
  
  left_tableau =  matrix(data = 0, nrow = row_count, ncol = variable_count);
  augmented_coefficient_matrix =  matrix(data = 0, nrow = row_count, ncol = variable_count+1);
  ################### END VARIABLE INITIALIZATION ###################
  
  # save objective function coefficients and variables to their respective arrays
  for( i in seq( 1:variable_count ) ){
    variables[i] = objective_function_split[i*2];
    objective_function[i] = as.numeric(objective_function_split[i*2-1]);
  }
  
  # save constraint's coefficients to a matrix
  for( i in seq( 1:constraint_count ) ){
    constraint = unlist(strsplit(deparse(constraints[i]), "=|\n|\"|\\*|\\+|<|>| "));
    constraint = constraint[constraint != ""];
    
    for( j in seq( 1:(length(constraint)/2) ) ){
      for( k in seq( 1:variable_count ) ){
        if( identical( variables[k], constraint[j*2] ) ){
          left_tableau[i, k] = as.numeric(constraint[j*2-1]);
        }
      }
    }
    solutions[i] = as.numeric(constraint[length(constraint)]);
  }
  left_tableau[row_count, 1:variable_count] = objective_function;
  
  augmented_coefficient_matrix[, 1:variable_count] = left_tableau;
  augmented_coefficient_matrix[, variable_count+1] = solutions;
  
  # if the goal is to minimize, transpose the matrix
  if(goal == 2){
    row_count = ncol(augmented_coefficient_matrix);
    column_count = nrow(augmented_coefficient_matrix) + row_count + 1;
    transposed = t(augmented_coefficient_matrix);
    augmented_coefficient_matrix = matrix(data = 0, nrow = row_count, ncol = column_count - row_count - 1, byrow = FALSE, dimnames = NULL)
    augmented_coefficient_matrix = transposed;
  }
  augmented_coefficient_matrix[row_count, ] = augmented_coefficient_matrix[row_count, ] * (-1);
  
  # populate slack variable names by corresponding names and slack matrix by diagonal matrix  
  slack_count = row_count-1;
  if(goal == 2)
    slack_count = constraint_count;
  
  slack_variables_names = array(data = "", dim = slack_count, dimnames = NULL);
  for(i in seq( 1 : slack_count ))
    slack_variables_names[i] = paste0("Slack ",i);
  
  slack = matrix(data = 0, nrow = row_count, ncol = row_count);
  for(i in seq( 1 : row_count ))
    slack[i,i] = 1;
  
  # create 2 arrays containing column names and row names respectively
  column_names = array(data = c(variables, slack_variables_names, optimization_variable, "Solution", "Test Ratio"), dim = column_count, dimnames = NULL);
  if(goal == 2)
    column_names = array(data = c(slack_variables_names, variables, optimization_variable, "Solution", "Test Ratio"), dim = column_count, dimnames = NULL);
  
  row_names = array(data = 1:row_count, dim = row_count, dimnames = NULL);
  
  # populate initial tableau
  tableau = matrix(data = 0, nrow = row_count, ncol = column_count, dimnames = list(row_names, column_names));
  tableau[, 1:(ncol(augmented_coefficient_matrix)-1)] = augmented_coefficient_matrix[, 1:(ncol(augmented_coefficient_matrix)-1)];
  tableau[, ncol(augmented_coefficient_matrix):(column_count-2)] = slack;
  tableau[, (ncol(tableau)-1)] = augmented_coefficient_matrix[, ncol(augmented_coefficient_matrix)];
  tableau[, ncol(tableau)] = NA;
  
  # result_list : list containing optimized variable, other variables used, and the initial tableau
  result_list = list(optimization_variable = optimization_variable, variables = variables, tableau = tableau);
  return(result_list);
}